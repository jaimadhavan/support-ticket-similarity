import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Category, TicketService } from '../services/ticket.service';

@Component({
  selector: 'app-categories-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './categories-page.component.html',
  styleUrl: './admin-pages.component.css'
})
export class CategoriesPageComponent implements OnInit {
  categories = signal<Category[]>([]);
  loading = signal(false);
  error = signal('');
  message = signal('');
  categoryName = '';
  editingId: number | null = null;
  confirmingDeleteId: number | null = null;

  constructor(private ticketService: TicketService) {}

  ngOnInit() {
    this.loadCategories();
  }

  loadCategories() {
    this.loading.set(true);
    this.error.set('');
    this.ticketService.getCategories().subscribe({
      next: response => {
        this.categories.set(response.categories);
        this.loading.set(false);
      },
      error: error => {
        console.error('Category list error:', error);
        this.error.set(error.error?.error || 'Unable to load categories.');
        this.loading.set(false);
      }
    });
  }

  toggleAccordion(event: MouseEvent, selected: HTMLDetailsElement, other: HTMLDetailsElement) {
    event.preventDefault();
    const shouldOpen = !selected.open;
    selected.open = shouldOpen;
    if (shouldOpen) {
      other.open = false;
    }
  }

  editCategory(
    category: Category,
    content?: HTMLElement,
    formAccordion?: HTMLDetailsElement,
    listAccordion?: HTMLDetailsElement,
    nameInput?: HTMLInputElement
  ) {
    this.editingId = category.id;
    this.categoryName = category.name;
    this.message.set('');
    this.error.set('');
    if (formAccordion) {
      formAccordion.open = true;
    }
    if (listAccordion) {
      listAccordion.open = false;
    }
    if (content) {
      content.scrollTop = 0;
    }
    nameInput?.focus();
  }

  cancelEdit(formAccordion?: HTMLDetailsElement, listAccordion?: HTMLDetailsElement) {
    this.editingId = null;
    this.categoryName = '';
    if (formAccordion) {
      formAccordion.open = false;
    }
    if (listAccordion) {
      listAccordion.open = true;
    }
  }

  saveCategory(formAccordion?: HTMLDetailsElement, listAccordion?: HTMLDetailsElement) {
    const name = this.categoryName.trim();
    if (!name) {
      this.error.set('Enter a category name.');
      return;
    }

    this.loading.set(true);
    this.error.set('');
    this.message.set('');
    const request = this.editingId === null
      ? this.ticketService.addCategory(name)
      : this.ticketService.updateCategory(this.editingId, name);
    request.subscribe({
      next: () => {
        this.message.set(this.editingId === null ? 'Category added.' : 'Category updated.');
        this.cancelEdit(formAccordion, listAccordion);
        this.loadCategories();
      },
      error: error => {
        console.error('Save category error:', error);
        this.error.set(error.error?.error || 'Unable to save category.');
        this.loading.set(false);
      }
    });
  }

  deactivateCategory(category: Category) {
    this.loading.set(true);
    this.error.set('');
    this.message.set('');
    this.ticketService.deactivateCategory(category.id).subscribe({
      next: response => {
        this.message.set(`${response.message}. Existing tickets keep this category.`);
        this.confirmingDeleteId = null;
        this.loadCategories();
      },
      error: error => {
        console.error('Deactivate category error:', error);
        this.error.set(error.error?.error || 'Unable to delete category.');
        this.loading.set(false);
      }
    });
  }
}
