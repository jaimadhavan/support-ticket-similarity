import { Component, ElementRef, OnInit, signal, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Category, TicketService } from '../services/ticket.service';

type AdminTab = 'form' | 'list';

@Component({
  selector: 'app-categories-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './categories-page.component.html',
  styleUrl: './admin-pages.component.css'
})
export class CategoriesPageComponent implements OnInit {
  categories = signal<Category[]>([]);
  loading = signal(false);
  error = signal('');
  message = signal('');
  categoryName = '';
  editingId: number | null = null;
  confirmingDeleteId: number | null = null;
  activeTab: AdminTab = 'list';
  private focusCategoryNameOnRender = false;

  @ViewChild('categoryNameInput')
  set categoryNameInput(input: ElementRef<HTMLInputElement> | undefined) {
    if (input && this.focusCategoryNameOnRender) {
      this.focusCategoryNameOnRender = false;
      input.nativeElement.focus();
    }
  }

  constructor(private ticketService: TicketService) {}

  ngOnInit() {
    this.loadCategories();
  }

  loadCategories() {
    this.loading.set(true);
    this.error.set('');
    this.ticketService.getCategories().subscribe({
      next: response => {
        this.categories.set(response.categories);
        this.loading.set(false);
      },
      error: error => {
        console.error('Category list error:', error);
        this.error.set(error.error?.error || 'Unable to load categories.');
        this.loading.set(false);
      }
    });
  }

  selectTab(tab: AdminTab) {
    this.activeTab = tab;
  }

  onTabKeydown(event: KeyboardEvent) {
    let nextTab: AdminTab;
    if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
      nextTab = this.activeTab === 'form' ? 'list' : 'form';
    } else if (event.key === 'End') {
      nextTab = 'list';
    } else if (event.key === 'Home') {
      nextTab = 'form';
    } else {
      return;
    }
    event.preventDefault();
    this.activeTab = nextTab;
    const nextButton = (event.currentTarget as HTMLElement).parentElement
      ?.querySelector<HTMLButtonElement>(`[data-admin-tab="${nextTab}"]`);
    nextButton?.focus();
  }

  editCategory(category: Category, content?: HTMLElement) {
    this.focusCategoryNameOnRender = true;
    this.activeTab = 'form';
    this.editingId = category.id;
    this.categoryName = category.name;
    this.message.set('');
    this.error.set('');
    if (content) {
      content.scrollTop = 0;
    }
  }

  cancelEdit() {
    this.editingId = null;
    this.categoryName = '';
    this.activeTab = 'list';
  }

  saveCategory() {
    const name = this.categoryName.trim();
    if (!name) {
      this.error.set('Enter a category name.');
      return;
    }

    this.loading.set(true);
    this.error.set('');
    this.message.set('');
    const request = this.editingId === null
      ? this.ticketService.addCategory(name)
      : this.ticketService.updateCategory(this.editingId, name);
    request.subscribe({
      next: () => {
        this.message.set(this.editingId === null ? 'Category added.' : 'Category updated.');
        this.cancelEdit();
        this.loadCategories();
      },
      error: error => {
        console.error('Save category error:', error);
        this.error.set(error.error?.error || 'Unable to save category.');
        this.loading.set(false);
      }
    });
  }

  deactivateCategory(category: Category) {
    this.loading.set(true);
    this.error.set('');
    this.message.set('');
    this.ticketService.deactivateCategory(category.id).subscribe({
      next: response => {
        this.message.set(`${response.message}. Existing tickets keep this category.`);
        this.confirmingDeleteId = null;
        this.loadCategories();
      },
      error: error => {
        console.error('Deactivate category error:', error);
        this.error.set(error.error?.error || 'Unable to delete category.');
        this.loading.set(false);
      }
    });
  }
}
